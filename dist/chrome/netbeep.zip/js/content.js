(function() {

    let browser;
    let isManifestV3 = false;
    if (typeof window.browser === 'undefined') {
        isManifestV3 = true;
        browser = window.chrome;
    }

    // how long to wait after domcontentloaded to get the data?
    const scrapeDelay = 2000;
    const apiURL = "https://random-video.com";
    const apiPassword = "jh6Zgi46s45fuzvutziGUzfurtedzhgjv";

    function onReady(callback) {
        if (document.readyState === "complete" || document.readyState === "interactive") {
            setTimeout(callback, scrapeDelay);
        } else {
            document.addEventListener("DOMContentLoaded", function() {
                setTimeout(callback, scrapeDelay);
            });
        }
    }

    function onPageChange() {
        // are we on a single video page like https://www.youtube.com/watch?v=cIB-FtssqZI
        if (window.location.href.indexOf("youtube.com/watch") > -1) {
            let videoData = getVideosFromSinglePage();

            console.log(videoData);
            console.log("rv-add: got " + videoData.length + " videos");

            browser.runtime.sendMessage({ action: "sendVideos", videos: videoData, apiURL: apiURL, apiPassword: apiPassword });
        }

        // channel page? starting youtube.com/@
        if (window.location.href.indexOf("youtube.com/@") > -1) {
            let videoData = getVideosFromChannelPage();

            console.log(videoData);
            console.log("rv-add: got " + videoData.length + " videos from channel page");

            browser.runtime.sendMessage({ action: "sendVideos", videos: videoData, apiURL: apiURL, apiPassword: apiPassword });
        }

        // playlist page? starting youtube.com/playlist
        if (window.location.href.indexOf("youtube.com/playlist") > -1) {
            let videoData = getVideosFromPlaylistPage();

            console.log(videoData);
            console.log("rv-add: got " + videoData.length + " videos from playlist page");

            browser.runtime.sendMessage({ action: "sendVideos", videos: videoData, apiURL: apiURL, apiPassword: apiPassword });
        }

        // feed page? starting youtube.com/feed
        if (window.location.href.indexOf("youtube.com/feed") > -1) {
            let videoData = getVideosFromFeedPage();

            console.log(videoData);
            console.log("rv-add: got " + videoData.length + " videos from feed page");

            browser.runtime.sendMessage({ action: "sendVideos", videos: videoData, apiURL: apiURL, apiPassword: apiPassword });
        }

        // search results page? starting youtube.com/results
        if (window.location.href.indexOf("youtube.com/results") > -1) {
            let videoData = getVideosFromResultsPage();

            console.log(videoData);
            console.log("rv-add: got " + videoData.length + " videos from results page");

            browser.runtime.sendMessage({ action: "sendVideos", videos: videoData, apiURL: apiURL, apiPassword: apiPassword });
        }

    }


    // on document load event
    onReady(function() {

        onPageChange();

        // listen to url changes
        let oldURL = window.location.href;
        setInterval(function() {
            if (window.location.href !== oldURL) {
                oldURL = window.location.href;
                setTimeout(onPageChange, 2000);
            }
        }, 500);

        // onscroll, get more videos
        let scrollTimeout;
        document.addEventListener('scroll', function() {
            // only once every 2 seconds
            if (!scrollTimeout) {
                scrollTimeout = setTimeout(function() {
                    scrollTimeout = null;
                    onPageChange();
                }, 2000);
            }
        });

    });

    /**
     * Get array of video metadata from a single video page like https://www.youtube.com/watch?v=cIB-FtssqZI
     */
    function getVideosFromSinglePage() {
        let videos = [];

        // get main video
        let video = {};

        video.id = window.location.search.split('v=')[1];
        video.title = document.querySelector('meta[property="og:title"]').getAttribute('content');
        video.description = document.querySelector('meta[property="og:description"]').getAttribute('content');

        // something like '\n  3.346.031.729 Aufrufe • 30.01.2014\n'
        let tooltip = document.querySelector("#description-inner #tooltip").innerText;
        tooltip = tooltip.replace(/\n/g, '').trim();

        // get only the number before "Aufrufe" in "bla laber {number} Aufrufe bla laber". the number can have dots
        video.view_count = tooltip.match(/(\d{1,3}\.)*\d+\sAufrufe/)[0].replace(" Aufrufe", "").replaceAll(".", "");

        // get the text after the middot
        video.upload_date = tooltip.split("•")[1].trim();

        //video.view_count = document.querySelector("#info-container #info.ytd-watch-info-text span:nth-of-type(1)").innerText;
        //video.upload_date = document.querySelector("#info-container #info.ytd-watch-info-text span:nth-of-type(3)").innerText;

        video.language_code = '';

        if (video.id && video.id.length === 11 && video.id.length === 11 && video.title && video.view_count && video.upload_date) {

            videos.push(video);
        }

        // get videos from sidebar
        let sidebarItems = document.querySelectorAll("#items ytd-compact-video-renderer");
        sidebarItems.forEach(function(item) {
            let video = {};

            try {
                video.id = item.querySelector("a#thumbnail").getAttribute('href').split('v=')[1].substring(0, 11);
                video.title = item.querySelector("#video-title").innerText;
                video.description = "";

                // something like "Hotel Transylvania 3 (2018) – DJ-Battle-Szene | Movieclips von Movieclips 296.024.736 Aufrufe vor 5 Jahren 4 Minuten, 42 Sekunden"
                let ariaLabel = item.querySelector("#video-title").getAttribute('aria-label');

                // get the number before "Aufrufe" in "bla laber {number} Aufrufe bla laber". the number can have dots
                video.view_count = ariaLabel.match(/(\d{1,3}\.)*\d+\sAufrufe/)[0].replace(" Aufrufe", "").replaceAll(".", "");

                // get the text after "Aufrufe" in "bla laber {number} Aufrufe bla laber"
                video.upload_date = ariaLabel.match(/Aufrufe\s(.*)/)[1];
                video.language_code = '';

                if (video.id && video.id.length === 11 && video.title && video.view_count && video.upload_date) {
                    videos.push(video);
                }
            } catch (e) {
                console.log("rv-add: error getting video data from sidebar", e);
            }


        });


        return videos;
    }

    function getVideosFromChannelPage() {
        let videos = [];

        let videoItems = document.querySelectorAll("ytd-grid-video-renderer,ytd-rich-grid-row");
        videoItems.forEach(function(item) {
            let video = {};

            try {
                video.id = item.querySelector("a#thumbnail").getAttribute('href').split('v=')[1].substring(0, 11);
                video.title = item.querySelector("#video-title").innerText;
                video.description = "";

                // something like "Hotel Transylvania 3 (2018) – DJ-Battle-Szene | Movieclips von Movieclips 296.024.736 Aufrufe vor 5 Jahren 4 Minuten, 42 Sekunden"
                let ariaLabel = item.querySelector("#video-title").getAttribute('aria-label');

                // get the number before "Aufrufe" in "bla laber {number} Aufrufe bla laber". the number can have dots
                video.view_count = ariaLabel.match(/(\d{1,3}\.)*\d+\sAufrufe/)[0].replace(" Aufrufe", "").replaceAll(".", "");

                // get the text after "Aufrufe" in "bla laber {number} Aufrufe bla laber"
                video.upload_date = ariaLabel.match(/Aufrufe\s(.*)/)[1];


                video.language_code = '';

                if (video.id && video.id.length === 11 && video.title && video.view_count && video.upload_date) {
                    videos.push(video);
                }
            } catch (e) {
                console.log("rv-add: error getting video data from channel page", e);
            }

        });

        return videos;
    }

    function getVideosFromPlaylistPage() {
        let videos = [];

        let videoItems = document.querySelectorAll("ytd-playlist-video-renderer");
        videoItems.forEach(function(item) {
            let video = {};

            try {
                video.id = item.querySelector("a#thumbnail").getAttribute('href').split('v=')[1].substring(0, 11);
                video.title = item.querySelector("#video-title").innerText;
                video.description = "";

                // something like "Hotel Transylvania 3 (2018) – DJ-Battle-Szene | Movieclips von Movieclips 296.024.736 Aufrufe vor 5 Jahren 4 Minuten, 42 Sekunden"
                let ariaLabel = item.querySelector("#meta h3").getAttribute('aria-label');

                // get the number before "Aufrufe" in "bla laber {number} Aufrufe bla laber". the number can have dots
                video.view_count = ariaLabel.match(/(\d{1,3}\.)*\d+\sAufrufe/)[0].replace(" Aufrufe", "").replaceAll(".", "");

                // get the text after "Aufrufe" in "bla laber {number} Aufrufe bla laber"
                video.upload_date = ariaLabel.match(/Aufrufe\s(.*)/)[1];

                video.language_code = '';

                if (video.id && video.id.length === 11 && video.title && video.view_count && video.upload_date) {
                    videos.push(video);
                }
            } catch (e) {
                console.log("rv-add: error getting video data from playlist page", e);
            }

        });

        return videos;
    }

    function getVideosFromFeedPage() {
        let videos = [];

        let videoItems = document.querySelectorAll("ytd-video-renderer");
        videoItems.forEach(function(item) {
            let video = {};

            try {
                video.id = item.querySelector("a#thumbnail").getAttribute('href').split('v=')[1].substring(0, 11);
                video.title = item.querySelector("#video-title").innerText;
                video.description = "";

                // something like "Hotel Transylvania 3 (2018) – DJ-Battle-Szene | Movieclips von Movieclips 296.024.736 Aufrufe vor 5 Jahren 4 Minuten, 42 Sekunden"
                let ariaLabel = item.querySelector("#video-title").getAttribute('aria-label');

                // get the number before "Aufrufe" in "bla laber {number} Aufrufe bla laber". the number can have dots
                video.view_count = ariaLabel.match(/(\d{1,3}\.)*\d+\sAufrufe/)[0].replace(" Aufrufe", "").replaceAll(".", "");

                // get the text after "Aufrufe" in "bla laber {number} Aufrufe bla laber"
                video.upload_date = ariaLabel.match(/Aufrufe\s(.*)/)[1];

                video.language_code = '';

                if (video.id && video.id.length === 11 && video.title && video.view_count && video.upload_date) {
                    videos.push(video);
                }
            } catch (e) {
                console.log("rv-add: error getting video data from feed page", e);
            }

        });

        return videos;
    }

    function getVideosFromResultsPage() {
        let videos = [];

        let videoItems = document.querySelectorAll("ytd-video-renderer");
        videoItems.forEach(function(item) {
            let video = {};

            try {
                video.id = item.querySelector("a#thumbnail").getAttribute('href').split('v=')[1].substring(0, 11);
                video.title = item.querySelector("#video-title").innerText;
                video.description = "";

                // something like "Hotel Transylvania 3 (2018) – DJ-Battle-Szene | Movieclips von Movieclips 296.024.736 Aufrufe vor 5 Jahren 4 Minuten, 42 Sekunden"
                let ariaLabel = item.querySelector("#video-title").getAttribute('aria-label');

                // get the number before "Aufrufe" in "bla laber {number} Aufrufe bla laber". the number can have dots
                video.view_count = ariaLabel.match(/(\d{1,3}\.)*\d+\sAufrufe/)[0].replace(" Aufrufe", "").replaceAll(".", "");

                // get the text after "Aufrufe" in "bla laber {number} Aufrufe bla laber"
                video.upload_date = ariaLabel.match(/Aufrufe\s(.*)/)[1];

                video.language_code = '';

                if (video.id && video.id.length === 11 && video.title && video.view_count && video.upload_date) {
                    videos.push(video);
                }
            } catch (e) {
                console.log("rv-add: error getting video data from results page", e);
            }

        });

        return videos;
    }






})();